#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/chef-webui-go" -importPath chef-webui-go -srcPath "$SCRIPTPATH/src" -runMode prod
